HISTORICAL ODDS (built by odds_history_pull.py, all times UTC)
Leagues: NFL, NCAA football.  Books: DraftKings, FanDuel, Pinnacle.  Markets: moneyline (h2h), spreads, totals.
Seasons: 2025 (full, including playoffs/bowls) and 2026 to date.

odds_history.xlsx     Open this one. Sheets: Games (one row per game, wide), Closing Lines, Opening Lines.
games.csv             One row per game with each book's opening and closing spread, total and moneylines.
closing_lines.csv     Last line we captured before kickoff, per game / book / market / outcome.
opening_lines.csv     First line we captured, per game / book / market / outcome.
history_<league>.csv  Every snapshot (daily + pre-kickoff). Large; use for line movement.
events_<league>.csv   List of games found.

Games sheet columns are "<Book>: <value>": close_home_spread is the home team's spread at close
(negative = home favored), close_home_spread_price / close_away_spread_price are the two sides' prices,
close_total is the over/under, close_home_ml / close_away_ml are moneylines,
open_* are the same at the first snapshot we have. Spread/total prices are American odds.
book_last_update / market_last_update show when the book last changed that line; a value well before
snapshot_ts means the line was stale at that snapshot. Pinnacle odds come from its public site and can lag.
No scores are included: The Odds API only keeps 3 days of results.

Last built: 2026-10-16 19:49 UTC
